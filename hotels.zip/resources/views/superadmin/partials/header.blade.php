<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>super Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="{{URL::asset('admin/vendors/iconfonts/mdi/css/materialdesignicons.min.css')}}">
  <link rel="stylesheet" href="{{URL::asset('admin/vendors/css/vendor.bundle.base.css')}}">
  <!-- endinject -->
  <!-- inject:css -->
  <link rel="stylesheet" href="{{URL::asset('admin/css/style.css')}}">
  <!-- endinject -->
  <link rel="shortcut icon" href="{{URL::asset('admin/images/favicon.png')}}">
</head>