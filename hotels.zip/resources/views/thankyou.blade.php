@extends('layouts.app')
@section('content')
<h2>Thank you</h2>

@endsection
