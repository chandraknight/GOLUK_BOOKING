@extends('hotels.layouts.main')

@section('content')
<div class="container">
    <p class="jumbotron">Dashboard</p>

</div>
@endsection
